param(
    [switch]$Check
)

$ErrorActionPreference = 'Stop'
$packageRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$server = Join-Path $packageRoot 'server.py'

if (-not (Test-Path -LiteralPath $server)) {
    throw "Missing server.py: $server"
}

$env:NO_PROXY = 'localhost,127.0.0.1'
$env:no_proxy = 'localhost,127.0.0.1'

$pythonCommand = Get-Command py -ErrorAction SilentlyContinue
if ($pythonCommand) {
    $arguments = @('-3', $server)
    if ($Check) { $arguments += '--check' }
    & $pythonCommand.Source @arguments
    exit $LASTEXITCODE
}

$pythonCommand = Get-Command python -ErrorAction SilentlyContinue
if (-not $pythonCommand) {
    throw 'Python 3 was not found. Install Python 3.10+ or configure WorkBuddy with an absolute Python path.'
}

$arguments = @($server)
if ($Check) { $arguments += '--check' }
& $pythonCommand.Source @arguments
exit $LASTEXITCODE
