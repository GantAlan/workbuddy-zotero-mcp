# Notice

This folder is an independent, portable implementation of the Zotero Desktop
local API and Connector workflow used by the Codex Zotero integration.

The local reference plugin at
`C:\Users\Alan\.codex\plugins\cache\openai-curated-local\zotero\0.1.2`
declares an MIT license in its `plugin.json`. If source from that reference
plugin is reused in a redistribution, preserve the applicable copyright and
license notices. This package is not an official WorkBuddy plugin and is not
endorsed by Zotero or OpenAI.

The package does not include any Zotero database, PDF, API key, account token,
or proprietary Codex runtime.
