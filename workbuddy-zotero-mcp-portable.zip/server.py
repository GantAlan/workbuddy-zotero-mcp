#!/usr/bin/env python3
"""A portable stdio MCP server for Zotero Desktop.

The server speaks newline-delimited JSON-RPC on stdin/stdout.  Logs go to
stderr so a WorkBuddy MCP host can safely parse stdout as protocol messages.
"""

from __future__ import annotations

import argparse
import json
import sys
from typing import Any, Callable

from zotero_client import (
    ZoteroClient,
    ZoteroError,
    build_queue,
    count_bibtex_entries,
    journal_style_label,
    prepare_next,
    queue_status,
    update_queue_item,
)


SERVER_NAME = "workbuddy-zotero"
SERVER_VERSION = "0.1.1"
PROTOCOL_VERSION = "2025-03-26"


def required_string(arguments: dict[str, Any], name: str) -> str:
    value = arguments.get(name)
    if not isinstance(value, str) or not value.strip():
        raise ZoteroError(f"Missing required string argument: {name}")
    return value.strip()


def optional_string(arguments: dict[str, Any], name: str) -> str | None:
    value = arguments.get(name)
    if value is None:
        return None
    if not isinstance(value, str):
        raise ZoteroError(f"Argument must be a string: {name}")
    return value


def boolean(arguments: dict[str, Any], name: str, default: bool = False) -> bool:
    value = arguments.get(name, default)
    if not isinstance(value, bool):
        raise ZoteroError(f"Argument must be a boolean: {name}")
    return value


def integer(arguments: dict[str, Any], name: str, default: int) -> int:
    value = arguments.get(name, default)
    if isinstance(value, bool) or not isinstance(value, int):
        raise ZoteroError(f"Argument must be an integer: {name}")
    return value


def tool(
    name: str,
    description: str,
    properties: dict[str, Any] | None = None,
    required: list[str] | None = None,
) -> dict[str, Any]:
    return {
        "name": name,
        "description": description,
        "inputSchema": {
            "type": "object",
            "properties": properties or {},
            "required": required or [],
            "additionalProperties": False,
        },
    }


STRING = {"type": "string"}
BOOLEAN = {"type": "boolean"}
INTEGER = {"type": "integer"}


TOOLS = [
    tool("zotero_status", "Check whether Zotero Desktop, its local API, and Connector are reachable."),
    tool("zotero_probe", "Probe the standard safe Zotero local API and Connector routes."),
    tool(
        "zotero_collections",
        "List Zotero collections, optionally limited to top-level collections.",
        {"topOnly": BOOLEAN},
    ),
    tool(
        "zotero_inventory",
        "List Zotero items with title, authors, year, key, and publication metadata.",
        {"includeChildren": BOOLEAN},
    ),
    tool(
        "zotero_collection_items",
        "List top-level items in one collection in a deterministic order; optionally keep only records with a PDF child attachment.",
        {
            "collectionKey": STRING,
            "topOnly": BOOLEAN,
            "sort": STRING,
            "direction": {"type": "string", "enum": ["asc", "desc"]},
            "withPdf": BOOLEAN,
        },
        ["collectionKey"],
    ),
    tool(
        "zotero_search",
        "Search top-level Zotero items by text.",
        {"query": STRING, "withBibtexKeys": BOOLEAN},
        ["query"],
    ),
    tool(
        "zotero_get_item",
        "Get the complete Zotero item JSON for one item key.",
        {"itemKey": STRING},
        ["itemKey"],
    ),
    tool(
        "zotero_get_children",
        "List child notes and attachments for one Zotero item.",
        {"itemKey": STRING},
        ["itemKey"],
    ),
    tool(
        "zotero_get_fulltext",
        "Read Zotero-indexed full text for an attachment. Use only when the user requests document content.",
        {"attachmentKey": STRING, "maxChars": INTEGER},
        ["attachmentKey"],
    ),
    tool(
        "zotero_get_file_url",
        "Get Zotero's local file URL for an attachment. This may reveal a local path.",
        {"attachmentKey": STRING},
        ["attachmentKey"],
    ),
    tool("zotero_tags", "List Zotero tags and item counts."),
    tool("zotero_groups", "List synced Zotero group libraries visible locally."),
    tool(
        "zotero_export_bibtex",
        "Export one item or the local library as BibTeX.",
        {"itemKey": STRING, "includeChildren": BOOLEAN},
    ),
    tool(
        "zotero_citations",
        "Render formatted citations from Zotero using a CSL style name.",
        {"style": {"type": "string", "default": "apa"}},
    ),
    tool("zotero_selected_target", "Read the currently selected Zotero library or collection through Connector."),
    tool(
        "zotero_import_records",
        "Import BibTeX or RIS through Zotero Connector. Requires confirm=true because this modifies the Zotero library.",
        {
            "kind": {"type": "string", "enum": ["BibTeX", "RIS", "bibtex", "ris"]},
            "text": STRING,
            "session": STRING,
            "confirm": BOOLEAN,
        },
        ["kind", "text", "confirm"],
    ),
    tool(
        "zotero_set_local_api",
        "Enable or disable Zotero's local API preference. Requires confirm=true; restart is optional and can terminate Zotero.",
        {"enabled": BOOLEAN, "restart": BOOLEAN, "confirm": BOOLEAN},
        ["enabled", "confirm"],
    ),
    tool(
        "zotero_journal_style",
        "Look up configured journal style fields such as sciif, sci, sciUp, sciUpSmall, and eii in zoterostyle.json.",
        {"journalName": STRING, "styleFile": STRING},
        ["journalName"],
    ),
    tool(
        "zotero_build_reading_queue",
        "Build or read a persistent queue for one Zotero collection, sorted by dateAdded and optionally filtered to PDF records.",
        {
            "collectionKey": STRING,
            "collectionName": STRING,
            "queueFile": STRING,
            "requirePdf": BOOLEAN,
            "sort": STRING,
            "direction": {"type": "string", "enum": ["asc", "desc"]},
            "rebuild": BOOLEAN,
        },
        ["collectionKey", "queueFile"],
    ),
    tool(
        "zotero_queue_status",
        "Return pending, in-progress, done, and failed counts for a queue file.",
        {"queueFile": STRING},
        ["queueFile"],
    ),
    tool(
        "zotero_prepare_next",
        "Atomically claim the next pending paper in a queue for one worker.",
        {"queueFile": STRING, "workerId": STRING},
        ["queueFile"],
    ),
    tool(
        "zotero_mark_done",
        "Mark a queue item done after its Markdown note has been verified on disk.",
        {"queueFile": STRING, "itemKey": STRING, "outputFile": STRING},
        ["queueFile", "itemKey"],
    ),
    tool(
        "zotero_mark_failed",
        "Mark a queue item failed and store a short error message for later retry or inspection.",
        {"queueFile": STRING, "itemKey": STRING, "error": STRING},
        ["queueFile", "itemKey", "error"],
    ),
    tool(
        "zotero_reset_pending",
        "Return a queue item to pending so a later worker can retry it.",
        {"queueFile": STRING, "itemKey": STRING, "error": STRING},
        ["queueFile", "itemKey"],
    ),
]


class MCPServer:
    def __init__(self, client: ZoteroClient | None = None):
        self.client = client or ZoteroClient()
        self.handlers: dict[str, Callable[[dict[str, Any]], Any]] = {
            "zotero_status": lambda a: self.client.status(),
            "zotero_probe": lambda a: self.client.probe(),
            "zotero_collections": lambda a: self.client.collections(
                top_only=boolean(a, "topOnly", False)
            ),
            "zotero_inventory": lambda a: self.client.items(
                include_children=boolean(a, "includeChildren", False)
            ),
            "zotero_collection_items": self.handle_collection_items,
            "zotero_search": self.handle_search,
            "zotero_get_item": lambda a: self.client.get_item(required_string(a, "itemKey")),
            "zotero_get_children": lambda a: self.client.children(required_string(a, "itemKey")),
            "zotero_get_fulltext": self.handle_fulltext,
            "zotero_get_file_url": lambda a: {
                "attachmentKey": required_string(a, "attachmentKey"),
                "url": self.client.file_url(required_string(a, "attachmentKey")),
            },
            "zotero_tags": lambda a: self.client.tags(),
            "zotero_groups": lambda a: self.client.groups(),
            "zotero_export_bibtex": self.handle_export_bibtex,
            "zotero_citations": lambda a: self.client.citations(
                optional_string(a, "style") or "apa"
            ),
            "zotero_selected_target": lambda a: self.client.selected_target(),
            "zotero_import_records": self.handle_import_records,
            "zotero_set_local_api": self.handle_set_local_api,
            "zotero_journal_style": lambda a: journal_style_label(
                required_string(a, "journalName"), optional_string(a, "styleFile")
            ),
            "zotero_build_reading_queue": self.handle_build_queue,
            "zotero_queue_status": lambda a: queue_status(required_string(a, "queueFile")),
            "zotero_prepare_next": lambda a: prepare_next(
                required_string(a, "queueFile"), optional_string(a, "workerId")
            ),
            "zotero_mark_done": lambda a: update_queue_item(
                required_string(a, "queueFile"),
                item_key=required_string(a, "itemKey"),
                status="done",
                output_file=optional_string(a, "outputFile"),
            ),
            "zotero_mark_failed": lambda a: update_queue_item(
                required_string(a, "queueFile"),
                item_key=required_string(a, "itemKey"),
                status="failed",
                error=required_string(a, "error"),
            ),
            "zotero_reset_pending": lambda a: update_queue_item(
                required_string(a, "queueFile"),
                item_key=required_string(a, "itemKey"),
                status="pending",
                error=optional_string(a, "error"),
            ),
        }

    def handle_collection_items(self, arguments: dict[str, Any]) -> Any:
        return self.client.collection_items(
            required_string(arguments, "collectionKey"),
            top_only=boolean(arguments, "topOnly", True),
            sort=optional_string(arguments, "sort") or "dateAdded",
            direction=optional_string(arguments, "direction") or "desc",
            with_pdf=boolean(arguments, "withPdf", False),
        )

    def handle_search(self, arguments: dict[str, Any]) -> Any:
        return self.client.search(
            required_string(arguments, "query"),
            with_bibtex_keys=boolean(arguments, "withBibtexKeys", False),
        )

    def handle_fulltext(self, arguments: dict[str, Any]) -> Any:
        attachment_key = required_string(arguments, "attachmentKey")
        result = self.client.fulltext(attachment_key)
        max_chars = integer(arguments, "maxChars", 250000)
        if max_chars < 1:
            raise ZoteroError("maxChars must be at least 1")
        content = str(result.get("content") or "")
        result = dict(result)
        result["attachmentKey"] = attachment_key
        result["chars"] = len(content)
        if len(content) > max_chars:
            result["content"] = content[:max_chars]
            result["truncated"] = True
        else:
            result["truncated"] = False
        return result

    def handle_export_bibtex(self, arguments: dict[str, Any]) -> Any:
        item_key = optional_string(arguments, "itemKey")
        text = self.client.export_bibtex(
            item_key=item_key,
            include_children=boolean(arguments, "includeChildren", False),
        )
        return {"bibtex": text, "entries": count_bibtex_entries(text)}

    def handle_import_records(self, arguments: dict[str, Any]) -> Any:
        if not boolean(arguments, "confirm", False):
            raise ZoteroError(
                "Refusing to modify Zotero without confirm=true. "
                "This imports records into the selected Zotero library or collection."
            )
        return self.client.import_records(
            required_string(arguments, "text"),
            kind=required_string(arguments, "kind"),
            session=optional_string(arguments, "session"),
        )

    def handle_set_local_api(self, arguments: dict[str, Any]) -> Any:
        if not boolean(arguments, "confirm", False):
            raise ZoteroError(
                "Refusing to change Zotero preferences without confirm=true."
            )
        return self.client.set_local_api(
            boolean(arguments, "enabled"),
            restart=boolean(arguments, "restart", False),
        )

    def handle_build_queue(self, arguments: dict[str, Any]) -> Any:
        queue = build_queue(
            self.client,
            collection_key=required_string(arguments, "collectionKey"),
            collection_name=optional_string(arguments, "collectionName"),
            require_pdf=boolean(arguments, "requirePdf", True),
            sort=optional_string(arguments, "sort") or "dateAdded",
            direction=optional_string(arguments, "direction") or "desc",
            queue_file=required_string(arguments, "queueFile"),
            rebuild=boolean(arguments, "rebuild", False),
        )
        return {
            "queue": queue,
            "status": queue_status(required_string(arguments, "queueFile")),
        }

    def handle(self, message: Any) -> dict[str, Any] | None:
        if not isinstance(message, dict):
            return error_response(None, -32600, "Invalid Request")
        method = message.get("method")
        request_id = message.get("id")
        if not isinstance(method, str):
            return error_response(request_id, -32600, "Invalid Request")

        if method.startswith("notifications/"):
            return None
        if method == "ping":
            return success_response(request_id, {})
        if method == "initialize":
            return success_response(
                request_id,
                {
                    "protocolVersion": PROTOCOL_VERSION,
                    "capabilities": {"tools": {}},
                    "serverInfo": {"name": SERVER_NAME, "version": SERVER_VERSION},
                },
            )
        if method == "tools/list":
            return success_response(request_id, {"tools": TOOLS})
        if method == "tools/call":
            return self.handle_tool_call(request_id, message.get("params"))
        if method in {"shutdown", "exit"}:
            return success_response(request_id, {})
        return error_response(request_id, -32601, f"Method not found: {method}")

    def handle_tool_call(self, request_id: Any, params: Any) -> dict[str, Any]:
        if not isinstance(params, dict):
            return error_response(request_id, -32602, "tools/call params must be an object")
        name = params.get("name")
        arguments = params.get("arguments") or {}
        if not isinstance(name, str) or not name:
            return error_response(request_id, -32602, "tools/call requires a tool name")
        if not isinstance(arguments, dict):
            return error_response(request_id, -32602, "tools/call arguments must be an object")
        handler = self.handlers.get(name)
        if handler is None:
            return error_response(request_id, -32602, f"Unknown tool: {name}")
        try:
            result = handler(arguments)
            return success_response(
                request_id,
                {
                    "content": [
                        {
                            "type": "text",
                            "text": json.dumps(result, ensure_ascii=False, indent=2),
                        }
                    ],
                    "isError": False,
                },
            )
        except (ZoteroError, OSError, ValueError) as exc:
            return success_response(
                request_id,
                {
                    "content": [{"type": "text", "text": str(exc)}],
                    "isError": True,
                },
            )
        except Exception as exc:  # keep protocol alive for unexpected tool failures
            print(f"unexpected tool error in {name}: {exc}", file=sys.stderr, flush=True)
            return success_response(
                request_id,
                {
                    "content": [{"type": "text", "text": f"Unexpected error: {exc}"}],
                    "isError": True,
                },
            )

    def serve(self) -> None:
        for raw_line in sys.stdin:
            line = raw_line.strip()
            if not line:
                continue
            message: Any = None
            try:
                message = json.loads(line)
            except json.JSONDecodeError as exc:
                response = error_response(None, -32700, f"Parse error: {exc}")
            else:
                response = self.handle(message)
            if response is not None:
                sys.stdout.write(json.dumps(response, ensure_ascii=False) + "\n")
                sys.stdout.flush()
            if isinstance(message, dict) and message.get("method") == "exit":
                break


def success_response(request_id: Any, result: Any) -> dict[str, Any]:
    return {"jsonrpc": "2.0", "id": request_id, "result": result}


def error_response(request_id: Any, code: int, message: str) -> dict[str, Any]:
    return {
        "jsonrpc": "2.0",
        "id": request_id,
        "error": {"code": code, "message": message},
    }


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Portable Zotero MCP stdio server")
    parser.add_argument(
        "--check",
        action="store_true",
        help="Print local Zotero readiness JSON and exit instead of starting MCP",
    )
    args = parser.parse_args(argv)
    server = MCPServer()
    if args.check:
        print(json.dumps(server.client.status(), ensure_ascii=False, indent=2))
        return 0
    server.serve()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
