@echo off
setlocal
set NO_PROXY=localhost,127.0.0.1
set no_proxy=localhost,127.0.0.1
where py >nul 2>nul
if %ERRORLEVEL% EQU 0 (
  py -3 "%~dp0server.py" %*
  exit /b %ERRORLEVEL%
)
python "%~dp0server.py" %*
exit /b %ERRORLEVEL%
